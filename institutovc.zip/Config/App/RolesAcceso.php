<?php
/** Autorización central, basada en permisos en BD. ROOT tiene acceso inmutable. */
final class RolesAcceso
{
    private static $usuario = null;
    private static bool $consultado = false;
    private static ?array $permisos = null;

    /** Catálogo cerrado de permisos; códigos desconocidos nunca se conceden. */
    public static function catalogo(): array
    {
        return [
            'dashboard' => 'Ver dashboard y estadísticas',
            'pedidos.listar' => 'Consultar listado de pedidos',
            'pedidos.detalle' => 'Ver detalle y recetas de pedidos',
            'pedidos.administrar' => 'Administrar pedidos y validar micas',
            'recetas.leer' => 'Consultar recetas y adjuntos',
            'recetas.administrar' => 'Revisar y aprobar recetas',
            'citas.leer' => 'Ver calendario y consultar citas',
            'citas.crear' => 'Agendar citas',
            'citas.administrar' => 'Cancelar y administrar citas',
            'productos.leer' => 'Consultar inventario administrativo',
            'productos.administrar' => 'Crear y modificar productos',
            'categorias.leer' => 'Consultar categorías',
            'categorias.administrar' => 'Administrar categorías',
            'micas.leer' => 'Consultar materiales y precios',
            'micas.administrar' => 'Administrar materiales y precios',
            'usuarios.administrar' => 'Crear y editar usuarios',
        ];
    }

    public static function usuario(): ?array
    {
        if (self::$consultado) return self::$usuario;
        self::$consultado = true;
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        $id = (int)($_SESSION['ivc_admin_id'] ?? 0);
        if ($id < 1 || empty($_SESSION['email'])) return null;
        try {
            $pdo = (new Conexion())->conect();
            $q = $pdo->prepare('SELECT u.id,u.nombres,u.apellidos,u.correo,u.estado,u.id_rol,r.codigo AS rol FROM usuario u JOIN roles r ON r.id_rol=u.id_rol WHERE u.id=? AND r.activo=1 LIMIT 1');
            $q->execute([$id]); $u = $q->fetch(PDO::FETCH_ASSOC);
            if (!$u || (int)$u['estado'] !== 1 || !hash_equals(strtolower((string)$u['correo']), strtolower((string)$_SESSION['email']))) return null;
            $_SESSION['ivc_admin_rol'] = $u['rol'];
            return self::$usuario = $u;
        } catch (Throwable $e) { error_log('IVC RolesAcceso usuario: '.$e->getMessage()); return null; }
    }

    public static function rol(): ?string
    {
        $u = self::usuario(); return $u ? (string)$u['rol'] : null;
    }

    public static function permiso(string $accion): bool
    {
        $u = self::usuario();
        if (!$u) return false;
        if ($accion === 'roles.gestionar') return $u['rol'] === 'ROOT'; // No delegable.
        if (!array_key_exists($accion, self::catalogo())) return false;
        if ($u['rol'] === 'ROOT') return true;
        if (self::$permisos === null) {
            self::$permisos = [];
            try {
                $pdo = (new Conexion())->conect();
                $q = $pdo->prepare('SELECT permiso FROM rol_permisos WHERE id_rol=?');
                $q->execute([(int)$u['id_rol']]);
                foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $p) self::$permisos[(string)$p]=true;
            } catch (Throwable $e) { error_log('IVC RolesAcceso permisos: '.$e->getMessage()); return false; }
        }
        return !empty(self::$permisos[$accion]);
    }

    public static function destinoInicial(): string
    {
        foreach (['dashboard'=>'admin/home','citas.leer'=>'citas','pedidos.listar'=>'pedidos', 'productos.leer'=>'productos', 'categorias.leer'=>'categorias','micas.leer'=>'micas','recetas.leer'=>'recetasAdmin','usuarios.administrar'=>'usuarios'] as $permiso=>$ruta) {
            if (self::permiso($permiso)) return $ruta;
        }
        return 'admin';
    }

    public static function rutaPermitida(string $controlador, string $metodo): bool
    {
        $c=strtolower($controlador);$m=strtolower($metodo);
        if ($c==='admin') {
            if (in_array($m,['index','validar','salir'],true)) return true;
            return self::permiso('dashboard');
        }
        if ($c==='roles') return self::permiso('roles.gestionar');
        if ($c==='usuarios') return self::permiso('usuarios.administrar');
        if ($c==='productos' || $c==='categorias' || $c==='micas') {
            $read = ['index','listar','edit','obtener','historial','vergaleria'];
            return self::permiso($c . (in_array($m,$read,true)?'.leer':'.administrar'));
        }
        if ($c==='recetasadmin') {
            return self::permiso('recetas.'.(in_array($m,['index','listar','detalle','vistaprevia','archivo'],true)?'leer':'administrar'));
        }
        if ($c==='citas') {
            if (in_array($m,['index','listar','gethorariosdisponibles','verificarcorreoagenda'],true)) return self::permiso('citas.leer');
            if (in_array($m,['registrarcita','enviarcorreoagenda'],true)) return self::permiso('citas.crear');
            return self::permiso('citas.administrar');
        }
        if ($c==='pedidos') {
            if (in_array($m,['index','listar'],true)) return self::permiso('pedidos.listar');
            if ($m==='detalle') return self::permiso('pedidos.detalle');
            return self::permiso('pedidos.administrar');
        }
        return true; // Rutas públicas conservan su lógica actual.
    }

    public static function aplicar(string $controlador, string $metodo): void
    {
        $c=strtolower($controlador);$m=strtolower($metodo);
        if ($c==='admin' && in_array($m,['index','validar','salir'],true)) return;
        if (!in_array($c,['admin','roles','usuarios','productos','categorias','micas','recetasadmin','pedidos','citas'],true)) return;
        if (!self::usuario()) self::denegar(401,'Inicia sesión para continuar.');
        if (!self::rutaPermitida($controlador,$metodo)) self::denegar(403,'No tienes permiso para realizar esta operación.');
    }

    private static function denegar(int $codigo,string $mensaje): void
    {
        http_response_code($codigo);header('Cache-Control: no-store');
        $accept=strtolower((string)($_SERVER['HTTP_ACCEPT']??''));
        $ajax=str_contains($accept,'json') || strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH']??''))==='xmlhttprequest';
        if ($ajax || strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'))==='POST') {
            header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'icono'=>'error','msg'=>$mensaje],JSON_UNESCAPED_UNICODE);
        } elseif ($codigo===401) {
            header('Location: '.BASE_URL.'admin');
        } else {
            header('Content-Type: text/html; charset=utf-8');
            echo '<!doctype html><html lang="es"><meta charset="utf-8"><title>Acceso restringido</title><div style="font:16px Arial;max-width:540px;margin:12vh auto;padding:28px;border:1px solid #ddd;border-radius:14px"><h1>Acceso restringido</h1><p>'.htmlspecialchars($mensaje,ENT_QUOTES,'UTF-8').'</p><a href="'.htmlspecialchars(BASE_URL.'admin',ENT_QUOTES,'UTF-8').'">Regresar</a></div>';
        }
        exit;
    }
}
