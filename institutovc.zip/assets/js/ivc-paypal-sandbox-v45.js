/** IVC 4.6 — PayPal SOLO SANDBOX, pedidos transaccionales y conciliación sin recobro. */
(() => {
  'use strict';
  const box = document.getElementById('ivc45Sandbox');
  if (!box || window.IVCPaypal45) return;
  const root = document.getElementById('ivcCheckoutQuote44');
  const base = root?.dataset.base || '/institutovc/';
  const status = document.getElementById('ivc45Status');
  const buttonContainer = document.getElementById('ivc45Buttons');
  const recovery = document.getElementById('ivc46Recovery');
  const CACHE = 'ivc46OrdenEnConciliacion';
  let quoteId = null, csrf = null, sdkPromise = null, rendering = false;
  let completed = false;
  const msg = (text, error = false) => {
    status.textContent = text;
    status.classList.toggle('is-error', error);
  };
  async function api(path, body) {
    const reply = await fetch(base + 'pagos/' + path, {
      credentials: 'same-origin', cache: 'no-store',
      ...(body ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...body,csrf})}
                 : {method:'GET'}),
    });
    const result = await reply.json().catch(() => {throw new Error('Respuesta PHP inválida.');});
    if (!reply.ok || result.ok !== true) throw new Error(result.msg || 'No se pudo completar la operación.');
    return result;
  }
  async function getToken() {
    const response = await fetch(base+'cotizaciones/token',{credentials:'same-origin',cache:'no-store'});
    const data = await response.json();
    if (!response.ok || !data.ok || !data.csrf) throw new Error(data.msg || 'Sesión de cliente no válida.');
    csrf=data.csrf;
  }
  const loadSdk = clientId => {
    if (sdkPromise) return sdkPromise;
    sdkPromise = new Promise((resolve,reject) => {
      const script = document.createElement('script');
      const params=new URLSearchParams({
        'client-id':clientId, currency:'MXN', intent:'capture', components:'buttons'
      });
      script.src='https://www.paypal.com/sdk/js?'+params.toString();
      script.setAttribute('data-namespace', 'paypalIVCSandbox');
      script.async=true;
      script.onload=()=>window.paypalIVCSandbox?.Buttons ? resolve(window.paypalIVCSandbox) : reject(new Error('No se pudo inicializar PayPal Sandbox.'));
      script.onerror=()=>reject(new Error('No se pudo cargar el SDK de PayPal Sandbox.'));
      document.head.append(script);
    });
    return sdkPromise;
  };
  function assertQuote() {
    const current=window.IVCCheckout44?.getQuoteId?.();
    if (!quoteId || String(current) !== String(quoteId) || !window.IVCCheckout44?.hasQuote?.()) {
      throw new Error('La cotización cambió. Vuelve a validar los precios antes de pagar.');
    }
  }
  function readCache() {
    try {
      const obj=JSON.parse(sessionStorage.getItem(CACHE) || 'null');
      return obj && Number.isSafeInteger(obj.id_cotizacion) && obj.id_cotizacion>0 ? obj : null;
    } catch (_) {return null;}
  }
  function remember(id, orderId) {
    try {sessionStorage.setItem(CACHE,JSON.stringify({id_cotizacion:Number(id),order_id:orderId}));}
    catch (_) { /* La conciliación también queda accesible en MySQL. */ }
  }
  function botonValoracion(container, result) {
    if (!container || !result?.pedido_creado || !result.requiere_valoracion || !Number.isSafeInteger(Number(result.id_pedido))) return;
    const a=document.createElement('a');a.href=base+'principal/agendar?pedido='+encodeURIComponent(result.id_pedido);
    a.textContent='Agendar valoración del pedido #'+result.id_pedido;
    a.className='btn btn-outline-primary btn-sm mt-2';a.style.display='inline-block';
    container.append(document.createElement('br'),a);
  }
  function finish(result, fromPayment) {
    if (result.pedido_creado) {
      if (fromPayment) {
        // El checkout ya fue verificado contra el carrito actual; no cambiar citas ni precios.
        localStorage.removeItem('listaCarrito');
        localStorage.removeItem('ivcCarritoConfiguradoV43');
      }
      try {
        const old=readCache();
        if (old && (fromPayment || Number(old.id_cotizacion)===Number(result.id_cotizacion))) sessionStorage.removeItem(CACHE);
      } catch (_) { /* Opcional */ }
      const citas=result.requiere_valoracion ? ' Requiere agendar valoración antes de fabricar.' : '';
      return `✅ Pedido #${result.id_pedido} creado. Pago SANDBOX: ${result.total} MXN. ${result.ya_registrada ? 'Ya estaba registrado; inventario sin doble descuento.' : 'Inventario reservado convertido en venta.'}${citas}`;
    }
    return `⚠️ PAGO SANDBOX CAPTURADO por ${result.total} MXN, pero PEDIDO PENDIENTE. NO vuelvas a pagar. Utiliza «Recuperar pedido» o solicita revisión administrativa.`;
  }
  async function recoverQuote(id, button) {
    const saved=button?.textContent || '';
    if (button) {button.disabled=true;button.textContent='Verificando sin volver a cobrar…';}
    try {
      await getToken();
      const result=await api('recuperar',{id_cotizacion:Number(id)});
      const text=finish(result,false);
      if (result.pedido_creado) await listPending();
      if (recovery) {
        const note=document.createElement('p');
        note.textContent=text;
        note.className=result.pedido_creado ? 'ivc46-recover-ok' : 'ivc46-recover-alert';
        recovery.prepend(note);
        botonValoracion(note,result);
      }
    } catch (error) {
      if (recovery) {
        const note=document.createElement('p'); note.className='ivc46-recover-alert';
        note.textContent='Cotización #'+id+': '+error.message+' No se inició ningún cobro nuevo.';
        recovery.prepend(note);
      }
    } finally {if(button){button.disabled=false;button.textContent=saved;}}
  }
  async function listPending() {
    if (!recovery) return;
    try {
      const result=await api('pendientes');
      const candidates=new Map();
      for (const item of result.capturas || []) candidates.set(Number(item.id_cotizacion),item);
      const stored=readCache();
      if (stored && !candidates.has(Number(stored.id_cotizacion))) {
        candidates.set(Number(stored.id_cotizacion),{id_cotizacion:stored.id_cotizacion,temporal:true});
      }
      recovery.replaceChildren();
      if (!candidates.size) return;
      const title=document.createElement('strong');
      title.textContent='¿Tienes un pago pendiente de confirmar?';
      recovery.append(title);
      const text=document.createElement('p');
      text.textContent='Puedes verificar estas órdenes contra PayPal y recuperar el pedido sin realizar otro cobro:';
      recovery.append(text);
      for (const item of candidates.values()) {
        const button=document.createElement('button');
        button.type='button';button.className='ivc46-recover-btn';
        button.textContent='Recuperar cotización #'+item.id_cotizacion;
        button.addEventListener('click',()=>recoverQuote(item.id_cotizacion,button));
        recovery.append(button);
      }
    } catch(error) {console.warn('IVC conciliación',error.message);}
  }
  async function render(quote) {
    if (rendering || completed) return;
    rendering=true;quoteId=quote;
    box.hidden=false;
    buttonContainer.replaceChildren();
    msg('Cargando entorno de prueba de PayPal…');
    try {
      await getToken();
      const config=await api('configuracion');
      if (!config.sandbox || config.currency!=='MXN' || !config.client_id) throw new Error('Solo se permite PayPal Sandbox en esta fase.');
      const sdk=await loadSdk(config.client_id);
      assertQuote();
      const instance=sdk.Buttons({
        style:{color:'blue',shape:'pill',label:'paypal',height:42},
        createOrder: async () => {
          assertQuote();
          const result=await api('crear',{id_cotizacion:Number(quoteId)});
          assertQuote();
          remember(quoteId,result.order_id);
          if (result.reserva_expira_en) msg('Inventario reservado temporalmente hasta '+result.reserva_expira_en+' (hora del servidor). Completa el pago antes de ese límite.');
          return result.order_id;
        },
        onApprove: async data => {
          try {
            assertQuote();
            const result=await api('capturar',{id_cotizacion:Number(quoteId),order_id:data.orderID});
            completed=true;
            msg(finish(result,true),!result.pedido_creado);
            botonValoracion(status,result);
            buttonContainer.replaceChildren();
            box.classList.add('ivc45-complete');
            if (!result.pedido_creado) listPending();
            else if(recovery) recovery.replaceChildren();
          } catch(error) {
            msg('No se pudo comprobar el estado de la captura: '+error.message+' No intentes pagar de nuevo. Usa Recuperar pedido.',true);
            listPending();
          }
        },
        onCancel: () => msg('Pago cancelado. El inventario se liberará automáticamente al vencer la reserva; no se efectuó un nuevo cargo.'),
        onError: error => {console.error('IVC PayPal Sandbox',error);msg('Error PayPal. No repitas un cobro hasta comprobar su estado.',true);listPending();},
      });
      if (!instance.isEligible()) throw new Error('Los botones PayPal no están disponibles con esta cuenta Sandbox.');
      await instance.render('#ivc45Buttons');
      msg('Sandbox listo. Usa una cuenta compradora de pruebas, no tu cuenta personal.');
    } catch(error) {msg(error.message,true);}
    finally {rendering=false;}
  }
  document.addEventListener('ivc:cotizacion-lista', event => {
    const id=Number(event.detail?.id);
    if (!Number.isSafeInteger(id)||id<=0) return;
    if (quoteId===id && !box.hidden) return;
    render(id);
  });
  document.addEventListener('ivc:cotizacion-invalidada', () => {
    quoteId=null;csrf=null;
    if(!completed){box.hidden=true;buttonContainer.replaceChildren();msg('');}
  });
  window.IVCPaypal45={getQuoteId:()=>quoteId, recuperar:recoverQuote};
  listPending();
})();
