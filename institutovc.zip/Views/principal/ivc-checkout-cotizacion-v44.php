<!-- IVC F4.6: cotización PHP, pedido con inventario y PayPal SOLO SANDBOX. -->
<section class="ivc44-root" id="ivcCheckoutQuote44" hidden aria-labelledby="ivc44Title" data-base="<?php echo htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8'); ?>">
  <div class="ivc44-progress" aria-label="Etapas del pedido">
    <span class="ivc44-current"><b>01</b> Revisar carrito</span>
    <span><b>02</b> Cotización PHP</span>
    <span><b>03</b> PayPal Sandbox · pruebas</span>
  </div>
  <header class="ivc44-heading">
    <span class="ivc44-eyebrow">TU COMPRA · PRECIOS VERIFICADOS</span>
    <h2 id="ivc44Title">Confirma tus armazones y micas</h2>
    <p>Revisaremos todos los productos juntos. El precio definitivo se obtiene de MySQL y se calcula desde PHP, sin tomar importes del navegador.</p>
  </header>
  <div class="ivc44-grid">
    <div class="ivc44-panel">
      <div class="ivc44-panel-head"><h3>Artículos del carrito</h3><span id="ivc44Count">—</span></div>
      <p class="ivc44-hint">La configuración de cada armazón se respeta por separado. Puedes modificarla desde el carrito antes de cotizar.</p>
      <div class="ivc44-table-wrap"><table class="ivc44-table"><thead><tr><th>Artículo</th><th>Graduación</th><th>Cantidad</th></tr></thead><tbody id="ivc44Preview"><tr><td colspan="3">Preparando carrito…</td></tr></tbody></table></div>
      <a class="ivc44-back" href="<?php echo htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8'); ?>principal/shop">← Regresar a la colección</a>
    </div>
    <aside class="ivc44-panel ivc44-summary" aria-label="Cotización del pedido">
      <span class="ivc44-eyebrow">COTIZACIÓN OFICIAL</span>
      <h3>Resumen de precios</h3>
      <div id="ivc44BeforeQuote" class="ivc44-before">Presiona <strong>«Validar precios en PHP»</strong> para recibir el importe real de todos tus armazones y micas.</div>
      <div id="ivc44Quote" hidden>
        <div class="ivc44-quote-id">Cotización <strong id="ivc44QuoteId">—</strong><span id="ivc44QuoteState">ABIERTA</span></div>
        <div class="ivc44-quote-items" id="ivc44QuoteItems"></div>
        <dl class="ivc44-totals">
          <div><dt>Armazones</dt><dd id="ivc44Frames">—</dd></div>
          <div><dt>Pares de micas</dt><dd id="ivc44Lenses">—</dd></div>
          <div class="ivc44-grand"><dt>Total verificado</dt><dd id="ivc44Total">—</dd></div>
        </dl>
        <p class="ivc44-validity">Cotización válida durante <strong>15 minutos</strong> desde su creación. Los importes pueden variar si modificas los artículos o vence su vigencia. No reserva inventario.</p>
      </div>
      <p class="ivc44-status" id="ivc44Status" role="status" aria-live="polite"></p>
      <button id="ivc44Generate" type="button" class="ivc44-primary">Validar precios en PHP →</button>
      <!-- IVC_F45_SANDBOX_PANEL -->
      <div class="ivc45-sandbox" id="ivc45Sandbox" hidden role="region" aria-label="Pruebas con PayPal Sandbox">
        <span class="ivc45-eyebrow">FASE 4.6 · ENTORNO DE PRUEBAS</span>
        <h4>PayPal Sandbox · Sin dinero real</h4>
        <p>El importe se obtiene de tu cotización en MySQL. La compra Sandbox registra un pedido de prueba en MySQL, descuenta inventario y conserva la receta o valoración pendiente. No utilices esta integración para cobrar dinero real.</p>
        <div id="ivc45Buttons"></div>
        <p id="ivc45Status" role="status" aria-live="polite"></p>
      </div>
      <div id="ivc46Recovery" class="ivc46-recovery" role="region" aria-label="Conciliación de pagos pendientes"></div>
      <div class="ivc44-payment-locked" role="note"><strong>Producción bloqueada.</strong><p>Esta fase permite únicamente pruebas Sandbox. No habilites PayPal Live hasta validar inventario, conciliación, recetas y reembolsos.</p></div>
      <p class="ivc44-review">Las recetas externas requieren revisión por la óptica. Si solicitaste valoración, se deberá agendar antes de fabricar las micas.</p>
    </aside>
  </div>
</section>
